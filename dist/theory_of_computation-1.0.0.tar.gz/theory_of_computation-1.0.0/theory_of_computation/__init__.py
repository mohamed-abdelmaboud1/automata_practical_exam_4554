
from .dfa import dfa_substring_101
from .turing_machine_divisible_by_3 import turing_machine_divisible_by_3
